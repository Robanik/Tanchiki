// ============================================
// Collision - Robust collision detection & resolution
// ============================================

export class Collision {
    constructor(gameState) {
        this.gameState = gameState;
    }

    // Bullet hitting a player
    bulletHitsPlayer(bullet, player) {
        const halfSize = 25;
        return (
            bullet.x > player.x - halfSize &&
            bullet.x < player.x + halfSize &&
            bullet.z > player.z - halfSize &&
            bullet.z < player.z + halfSize
        );
    }

    // Bullet hitting a block
    bulletHitsBlock(bullet, block) {
        const halfW = block.width / 2;
        const halfD = block.depth / 2;
        return (
            bullet.x > block.x - halfW &&
            bullet.x < block.x + halfW &&
            bullet.z > block.z - halfD &&
            bullet.z < block.z + halfD
        );
    }

    // Player hitting a power-up (Circle-Circle)
    playerHitsPowerUp(player, powerUp) {
        const dx = player.x - powerUp.x;
        const dz = player.z - powerUp.z;
        const distSq = dx * dx + dz * dz;
        const radSum = 25 + powerUp.radius;
        return distSq < radSum * radSum;
    }

    /**
     * getPushback - Generic AABB pushback calculator
     * Returns the MINIMUM pushback vector to resolve collision
     */
    getAABBPushback(x1, z1, w1, d1, x2, z2, w2, d2) {
        const dx = x1 - x2;
        const dz = z1 - z2;
        const halfW = (w1 + w2) / 2;
        const halfD = (d1 + d2) / 2;

        const overlapX = halfW - Math.abs(dx);
        const overlapZ = halfD - Math.abs(dz);

        if (overlapX > 0 && overlapZ > 0) {
            // Resolve along the axis of shallowest penetration
            if (overlapX < overlapZ) {
                return { x: dx > 0 ? overlapX : -overlapX, z: 0 };
            } else {
                return { x: 0, z: dz > 0 ? overlapZ : -overlapZ };
            }
        }
        return null;
    }

    // Player vs Block Resolution
    getPlayerBlockPushback(player, block) {
        return this.getAABBPushback(
            player.x, player.z, 50, 50,
            block.x, block.z, block.width, block.depth
        );
    }

    // Player vs Player Resolution (Asymmetric)
    // Only player1 gets pushed back, player2 is considered an obstacle
    getPlayerPlayerPushback(player1, player2) {
        return this.getAABBPushback(
            player1.x, player1.z, 50, 50,
            player2.x, player2.z, 50, 50
        );
    }

    /**
     * checkAABBOverlap - Simple boolean overlap check
     */
    checkOverlap(x1, z1, w1, d1, x2, z2, w2, d2) {
        return (
            Math.abs(x1 - x2) < (w1 + w2) / 2 &&
            Math.abs(z1 - z2) < (d1 + d2) / 2
        );
    }

    distance(x1, z1, x2, z2) {
        return Math.sqrt((x2 - x1) ** 2 + (z2 - z1) ** 2);
    }
}