// ============================================
// DestructibleBlock - Server-side block entity
// ============================================

export class DestructibleBlock {
    constructor(id, x, z, isGolden = false) {
        this.id = id;
        this.x = x;
        this.z = z;
        this.isGolden = isGolden;

        // Random size variation
        this.width = 40 + Math.random() * 40;  // 40-80
        this.height = 30 + Math.random() * 30; // 30-60
        this.depth = 40 + Math.random() * 40;  // 40-80

        this.hp = isGolden ? 150 : 75; // Golden blocks are tougher
        this.maxHp = this.hp;

        this.createdAt = Date.now();
    }

    serialize() {
        return {
            id: this.id,
            x: Math.round(this.x),
            z: Math.round(this.z),
            w: Math.round(this.width),
            h: Math.round(this.height),
            d: Math.round(this.depth),
            hp: this.hp,
            isGolden: this.isGolden
        };
    }
}
