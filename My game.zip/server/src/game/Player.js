// ============================================
// Player - Server-side player entity
// ============================================

// Predefined tank colors for variety
const TANK_COLORS = [
    0x4ade80, // Green
    0xe74c3c, // Red
    0x3b82f6, // Blue
    0xf59e0b, // Orange
    0x8b5cf6, // Purple
    0xec4899, // Pink
    0x14b8a6, // Teal
    0xeab308, // Yellow
    0x6366f1, // Indigo
    0x06b6d4, // Cyan
];

export class Player {
    constructor(id, nickname, x, z) {
        this.id = id;
        this.nickname = nickname || 'Player';

        // Random tank color (consistent for this player)
        this.color = TANK_COLORS[Math.floor(Math.random() * TANK_COLORS.length)];

        // Position & rotation
        this.x = x;
        this.z = z;
        this.vx = 0;             // Velocity X
        this.vz = 0;             // Velocity Z
        this.bodyAngle = 0;      // Tank body rotation
        this.turretAngle = 0;    // Turret/gun rotation

        // Stats
        this.hp = 100;
        this.maxHp = 100;
        this.score = 0;
        this.kills = 0;
        this.deaths = 0;

        // State
        this.isAlive = true;
        this.invulnerableUntil = 0;
        this.cantShootUntil = 0;

        // Power-ups
        this.hasTripleShot = false;
        this.tripleShotUntil = 0;
        this.hasSpeedBoost = false;
        this.speedBoostUntil = 0;

        // Anti-bot heuristics
        this.roboticScore = 0;   // Higher = more likely a bot
        this.lastAngle = null;
        this.lastInputTime = 0;
        this.angleHistory = [];  // Track small changes for "too perfect" movements

        // Input state
        this.input = {
            up: false,
            down: false,
            left: false,
            right: false,
            angle: 0,
            shooting: false
        };

        // Timing
        this.lastShotTime = 0;
        this.lastUpdateTime = Date.now();
    }

    updateInput(inputData) {
        const now = Date.now();
        const deltaTime = now - this.lastInputTime;

        // HEURISTIC 1: Check for "perfect" turret movement (bots often snap or use fixed increments)
        if (this.lastAngle !== null && inputData.angle !== this.lastAngle) {
            const diff = Math.abs(inputData.angle - this.lastAngle);

            // If angle is exactly 0.1, 0.05, etc. (robot increments)
            // Use a small epsilon for precision checks
            const isPrecisionIncrement = (diff * 100) % 1 < 0.001 || (diff * 100) % 1 > 0.999;
            if (diff > 0 && isPrecisionIncrement && diff < 1) {
                this.roboticScore += 0.2; // Reduced weight for individual precision inputs
            }

            // High precision check - real humans rarely send angle with > 4 decimals exactly same over 10 inputs
            // (Simple version: just track variance)
            this.angleHistory.push(diff);
            if (this.angleHistory.length > 20) {
                this.angleHistory.shift();
                const variance = this.calculateVariance(this.angleHistory);
                if (variance < 0.00001) this.roboticScore += 2; // Zero variance in movement is suspicious
            }
        }

        // HEURISTIC 2: Constant packet intervals
        if (this.lastInputTime > 0) {
            // Human network jitter + human reaction usually varies
            // If every single packet is exactly 16ms, it's likely a script on the same machine/server
            if (Math.abs(deltaTime - 16.6) < 0.1) {
                // Too perfect for a web app over real network?
                // We'll be careful here to not punish local testers
            }
        }

        this.lastAngle = inputData.angle;
        this.lastInputTime = now;

        this.input.up = inputData.up || false;
        this.input.down = inputData.down || false;
        this.input.left = inputData.left || false;
        this.input.right = inputData.right || false;
        this.input.angle = inputData.angle || 0;
        this.input.shooting = inputData.shooting || false;
        this.lastInputSeq = inputData.seq || 0;
        this.lastUpdateTime = now;
    }

    calculateVariance(arr) {
        if (arr.length === 0) return 0;
        const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
        return arr.reduce((a, b) => a + (b - mean) ** 2, 0) / arr.length;
    }

    serialize() {
        return {
            id: this.id,
            n: this.nickname,
            c: this.color,
            x: Math.round(this.x * 10) / 10,
            z: Math.round(this.z * 10) / 10,
            ba: Math.round(this.bodyAngle * 100) / 100,
            ta: Math.round(this.turretAngle * 100) / 100,
            hp: this.hp,
            s: this.score,
            k: this.kills,
            d: this.deaths,
            a: this.isAlive,
            inv: Date.now() < this.invulnerableUntil,
            ts: this.hasTripleShot && Date.now() < this.tripleShotUntil,
            sp: this.hasSpeedBoost && Date.now() < this.speedBoostUntil,
            seq: this.lastInputSeq
        };
    }
}
