// ============================================
// Game Loop - Main server tick loop (optimized)
// ============================================

import { GameState } from './GameState.js';
import { Collision } from './Collision.js';

export class GameLoop {
    constructor() {
        this.gameState = new GameState();
        this.collision = new Collision(this.gameState);

        this.tickRate = 20; // Increased from 10 Hz for smoother experience
        this.tickInterval = 1000 / this.tickRate;
        this.lastTick = Date.now();
        this.isRunning = false;
        this.intervalId = null;

        // Performance monitoring
        this.tickTimes = [];
        this.maxTickSamples = 50;

        // Event callbacks
        this.onPlayerHit = null;
        this.onPlayerDeath = null;
        this.onPowerUpCollected = null;
        this.onBlockDestroyed = null;
        this.onArenaResize = null;
        this.onEventStart = null;
        this.onEventStop = null;
    }

    start() {
        if (this.isRunning) return;

        this.isRunning = true;
        this.lastTick = Date.now();

        this.intervalId = setInterval(() => {
            this.tick();
        }, this.tickInterval);

        console.log(`🎮 Game loop started at ${this.tickRate} Hz`);
    }

    stop() {
        this.isRunning = false;
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
        }
        console.log('🛑 Game loop stopped');
    }

    tick() {
        const tickStart = Date.now();
        const now = tickStart;
        const deltaTime = (now - this.lastTick) / 1000; // Convert to seconds
        this.lastTick = now;

        // Rebuild spatial hash for optimized collision detection
        this.rebuildSpatialHash();

        // Update all game entities
        this.updatePlayers(deltaTime);
        this.updateBullets(deltaTime, now);
        this.updatePowerUps();

        // Check collisions (now using spatial hash)
        this.checkCollisions();

        // Spawn new entities
        this.gameState.updateSpawns();

        // Check arena resize
        if (this.gameState.updateArenaSize() && this.onArenaResize) {
            this.onArenaResize(this.gameState.arenaSize);
        }

        // Check for event state changes
        if (this.gameState.isGoldenRush && !this._lastEventState) {
            if (this.onEventStart) this.onEventStart('goldenRush');
        } else if (!this.gameState.isGoldenRush && this._lastEventState) {
            if (this.onEventStop) this.onEventStop('goldenRush');
        }
        this._lastEventState = this.gameState.isGoldenRush;

        // Track performance
        const tickTime = Date.now() - tickStart;
        this.tickTimes.push(tickTime);
        if (this.tickTimes.length > this.maxTickSamples) {
            this.tickTimes.shift();
        }
    }

    rebuildSpatialHash() {
        const spatialHash = this.gameState.spatialHash;
        spatialHash.clear();

        // Add players
        for (const player of this.gameState.players.values()) {
            if (player.isAlive) {
                spatialHash.insert(player, 'player');
            }
        }

        // Add blocks
        for (const block of this.gameState.blocks.values()) {
            spatialHash.insert(block, 'block');
        }

        // Add power-ups
        for (const powerUp of this.gameState.powerUps.values()) {
            spatialHash.insert(powerUp, 'powerUp');
        }
    }

    getPerformanceStats() {
        if (this.tickTimes.length === 0) return null;
        const avg = this.tickTimes.reduce((a, b) => a + b, 0) / this.tickTimes.length;
        const max = Math.max(...this.tickTimes);
        return { avgTickMs: avg.toFixed(2), maxTickMs: max.toFixed(2) };
    }

    updatePlayers(deltaTime) {
        const halfArena = this.gameState.arenaSize / 2 - 30;

        for (const player of this.gameState.players.values()) {
            if (!player.isAlive) continue;

            // Physics constants
            const acceleration = 800; // Units per second squared
            const friction = 5;      // Friction coefficient
            let maxSpeed = this.gameState.config.playerSpeed;

            // Speed boost from power-up
            if (player.hasSpeedBoost && Date.now() < player.speedBoostUntil) {
                maxSpeed *= 1.5;
            } else {
                player.hasSpeedBoost = false;
            }

            // Calculate input direction
            let inputX = 0, inputZ = 0;
            if (player.input.up) inputZ -= 1;
            if (player.input.down) inputZ += 1;
            if (player.input.left) inputX -= 1;
            if (player.input.right) inputX += 1;

            // Normalize input
            if (inputX !== 0 && inputZ !== 0) {
                const len = Math.sqrt(inputX * inputX + inputZ * inputZ);
                inputX /= len;
                inputZ /= len;
            }

            // Apply acceleration
            player.vx += inputX * acceleration * deltaTime;
            player.vz += inputZ * acceleration * deltaTime;

            // Apply friction
            player.vx -= player.vx * friction * deltaTime;
            player.vz -= player.vz * friction * deltaTime;

            // Limit to max speed
            const currentSpeed = Math.sqrt(player.vx * player.vx + player.vz * player.vz);
            if (currentSpeed > maxSpeed) {
                const ratio = maxSpeed / currentSpeed;
                player.vx *= ratio;
                player.vz *= ratio;
            }

            // Apply movement (with small speed cutoff to prevent infinite micro-movement)
            if (Math.abs(player.vx) < 1) player.vx = 0;
            if (Math.abs(player.vz) < 1) player.vz = 0;

            // Apply movement
            const oldX = player.x;
            const oldZ = player.z;

            player.x += player.vx * deltaTime;
            player.z += player.vz * deltaTime;

            // Strict anti-teleport/speed check
            const movedDist = Math.sqrt((player.x - oldX) ** 2 + (player.z - oldZ) ** 2);
            const absoluteMax = maxSpeed * deltaTime * 1.5; // Allow 50% extra for lag, down from 100%

            if (movedDist > absoluteMax && movedDist > 20) {
                // Suspiciously fast movement - snap back part way or full way
                player.x = oldX;
                player.z = oldZ;
                player.vx = 0;
                player.vz = 0;
            }

            // Clamp to arena bounds
            player.x = Math.max(-halfArena, Math.min(halfArena, player.x));
            player.z = Math.max(-halfArena, Math.min(halfArena, player.z));

            // Update turret rotation (strictly normalized to 0-2PI)
            player.turretAngle = ((player.input.angle % (Math.PI * 2)) + (Math.PI * 2)) % (Math.PI * 2);

            // Update body rotation based on actual velocity
            if (Math.abs(player.vx) > 1 || Math.abs(player.vz) > 1) {
                player.bodyAngle = Math.atan2(player.vx, -player.vz);
            }
        }
    }

    updateBullets(deltaTime, now) {
        const halfArena = this.gameState.arenaSize / 2;
        const bulletsToRemove = [];

        // Use lifetime from config (750ms = 300 units range)
        const lifetime = this.gameState.config.bulletLifetime;

        for (const [id, bullet] of this.gameState.bullets) {
            // Move bullet
            bullet.x += bullet.vx * deltaTime;
            bullet.z += bullet.vz * deltaTime;

            // Check lifetime
            if (now - bullet.createdAt > lifetime) {
                bulletsToRemove.push(id);
                continue;
            }

            // Check arena bounds
            if (Math.abs(bullet.x) > halfArena || Math.abs(bullet.z) > halfArena) {
                bulletsToRemove.push(id);
            }
        }

        for (const id of bulletsToRemove) {
            this.gameState.removeBullet(id);
        }
    }

    updatePowerUps() {
        const now = Date.now();
        const toRemove = [];

        for (const [id, powerUp] of this.gameState.powerUps) {
            // Power-ups expire after 30 seconds
            if (now - powerUp.createdAt > 30000) {
                toRemove.push(id);
            }
        }

        for (const id of toRemove) {
            this.gameState.removePowerUp(id);
        }
    }

    checkCollisions() {
        // Optimized collision detection using SpatialHash
        // Single pass for bullets against players and blocks
        this.checkBulletCollisions();
        // Single pass for players against powerups and blocks
        this.checkPlayerCollisions();
    }

    checkBulletCollisions() {
        const bulletsToRemove = new Set();
        const blocksToRemove = new Set();
        const spatialHash = this.gameState.spatialHash;

        for (const [bulletId, bullet] of this.gameState.bullets) {
            if (bulletsToRemove.has(bulletId)) continue;

            // Query nearby objects (radius 50 covers player and block sizes)
            const nearby = spatialHash.query(bullet.x, bullet.z, 50);

            for (const item of nearby) {
                const { entity, type } = item;

                if (type === 'player') {
                    const player = entity;
                    // Skip own bullets and dead players
                    if (bullet.ownerId === player.id || !player.isAlive) continue;
                    // Skip invulnerable players
                    if (Date.now() < player.invulnerableUntil) continue;

                    if (this.collision.bulletHitsPlayer(bullet, player)) {
                        bulletsToRemove.add(bulletId);

                        // Apply damage
                        player.hp -= bullet.damage;

                        // Get shooter for score
                        const shooter = this.gameState.getPlayer(bullet.ownerId);

                        if (this.onPlayerHit) {
                            this.onPlayerHit(player.id, bullet.ownerId, bullet.damage);
                        }

                        if (player.hp <= 0) {
                            player.isAlive = false;
                            player.deaths++;

                            if (shooter) {
                                shooter.score += 100;
                                shooter.kills++;
                            }

                            if (this.onPlayerDeath) {
                                this.onPlayerDeath(player.id, bullet.ownerId);
                            }
                        }
                        break; // Bullet can only hit one player
                    }
                } else if (type === 'block') {
                    const block = entity;
                    if (blocksToRemove.has(block.id)) continue;

                    if (this.collision.bulletHitsBlock(bullet, block)) {
                        bulletsToRemove.add(bulletId);

                        block.hp -= bullet.damage;
                        if (block.hp <= 0) {
                            blocksToRemove.add(block.id);

                            // Award points for golden blocks
                            if (block.isGolden && shooter) {
                                shooter.score += 500;
                            }

                            if (this.onBlockDestroyed) {
                                this.onBlockDestroyed(block.id, block.isGolden);
                            }
                        }
                        break; // Bullet hits block
                    }
                }
            }
        }

        for (const id of bulletsToRemove) {
            this.gameState.removeBullet(id);
        }

        for (const id of blocksToRemove) {
            this.gameState.removeBlock(id);
        }
    }

    checkPlayerCollisions() {
        const powerUpsToRemove = new Set();
        const spatialHash = this.gameState.spatialHash;

        for (const player of this.gameState.players.values()) {
            if (!player.isAlive) continue;

            const nearby = spatialHash.query(player.x, player.z, 60);

            // 1. Resolve Blocks (High Priority, Multi-pass for corners)
            for (let i = 0; i < 2; i++) { // Two passes to handle corners/multiple blocks
                for (const item of nearby) {
                    if (item.type === 'block') {
                        const pushback = this.collision.getPlayerBlockPushback(player, item.entity);
                        if (pushback) {
                            player.x += pushback.x;
                            player.z += pushback.z;
                            // Kill velocity on blocked axis
                            if (pushback.x !== 0) player.vx = 0;
                            if (pushback.z !== 0) player.vz = 0;
                        }
                    }
                }
            }

            // 2. Resolve Players (Dynamic Blocking)
            for (const item of nearby) {
                if (item.type === 'player') {
                    const otherPlayer = item.entity;
                    if (otherPlayer.id === player.id || !otherPlayer.isAlive) continue;

                    const pushback = this.collision.getPlayerPlayerPushback(player, otherPlayer);
                    if (pushback) {
                        // Strict blocking: push the current player out of the other player
                        // No mutual pushing because we only update 'player' here
                        player.x += pushback.x;
                        player.z += pushback.z;

                        // Impact physics: stop momentum
                        player.vx = 0;
                        player.vz = 0;
                    }
                } else if (item.type === 'powerUp') {
                    const powerUp = item.entity;
                    if (powerUpsToRemove.has(powerUp.id)) continue;

                    if (this.collision.playerHitsPowerUp(player, powerUp)) {
                        powerUpsToRemove.add(powerUp.id);
                        this.applyPowerUp(player, powerUp);
                        if (this.onPowerUpCollected) {
                            this.onPowerUpCollected(player.id, powerUp.type);
                        }
                    }
                }
            }
        }

        for (const id of powerUpsToRemove) {
            this.gameState.removePowerUp(id);
        }
    }

    applyPowerUp(player, powerUp) {
        const now = Date.now();

        switch (powerUp.type) {
            case 'tripleShot':
                player.hasTripleShot = true;
                player.tripleShotUntil = now + 10000; // 10 seconds
                break;

            case 'speed':
                player.hasSpeedBoost = true;
                player.speedBoostUntil = now + 8000; // 8 seconds
                break;

            case 'heal':
                player.hp = Math.min(
                    this.gameState.config.playerMaxHp,
                    player.hp + 50
                );
                break;
        }
    }

    // Called from SocketHandler when player shoots
    playerShoot(playerId) {
        const player = this.gameState.getPlayer(playerId);
        if (!player || !player.isAlive) return [];

        const now = Date.now();

        // Check respawn shooting cooldown
        if (now < player.cantShootUntil) return [];

        // Fire rate limiting (1000ms = 1 second between shots)
        if (now - player.lastShotTime < 1000) return [];
        player.lastShotTime = now;

        // Check if triple shot is active
        const isTriple = player.hasTripleShot && now < player.tripleShotUntil;
        if (now >= player.tripleShotUntil) {
            player.hasTripleShot = false;
        }

        // Calculate bullet spawn position (at gun tip)
        const gunLength = 40;
        const spawnX = player.x + Math.sin(player.turretAngle) * gunLength;
        const spawnZ = player.z - Math.cos(player.turretAngle) * gunLength;

        return this.gameState.addBullet(
            playerId,
            spawnX,
            spawnZ,
            player.turretAngle,
            isTriple
        );
    }

    // Called when player respawns
    respawnPlayer(playerId) {
        const player = this.gameState.getPlayer(playerId);
        // Security: only allow respawn if dead
        if (!player || player.isAlive) return null;

        const pos = this.gameState.getRandomSpawnPosition();
        player.x = pos.x;
        player.z = pos.z;
        player.hp = this.gameState.config.playerMaxHp;
        player.isAlive = true;
        player.score = 0;
        player.hasTripleShot = false;
        player.hasSpeedBoost = false;
        player.invulnerableUntil = Date.now() + this.gameState.config.respawnInvulnerability;
        player.cantShootUntil = Date.now() + 2000; // 2 seconds shooting cooldown

        return player;
    }
}
