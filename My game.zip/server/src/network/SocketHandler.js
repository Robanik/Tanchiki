// ============================================
// SocketHandler - Network message handling
// ============================================

export class SocketHandler {
    constructor(io, gameLoop) {
        this.io = io;
        this.gameLoop = gameLoop;
        this.gameState = gameLoop.gameState;

        // Rate limiting: socketId -> lastPacketTime
        this.packetRates = new Map();
        this.packetLimit = 1000 / 60; // Max 60 packets per second

        // Anti-bot: IP throttling
        this.ipConnections = new Map(); // ip -> count
        this.maxConnectionsPerIp = 3;
        this.handshakeSecret = 'tanchiki_proto_v1_' + Math.floor(Date.now() / 100000); // Rotates every ~2 mins

        // Setup game loop callbacks
        this.setupGameCallbacks();

        // Broadcast state at fixed interval (optimized to 10 Hz)
        this.broadcastInterval = setInterval(() => {
            this.broadcastGameState();
        }, 1000 / 20); // 20 Hz (matches tick rate)

        // Broadcast leaderboard at 2 Hz
        this.leaderboardInterval = setInterval(() => {
            this.broadcastLeaderboard();
        }, 500);
    }

    setupGameCallbacks() {
        this.gameLoop.onPlayerHit = (targetId, shooterId, damage) => {
            this.io.emit('playerHit', { targetId, shooterId, damage });
        };

        this.gameLoop.onPlayerDeath = (playerId, killerId) => {
            const killer = this.gameState.getPlayer(killerId);
            const victim = this.gameState.getPlayer(playerId);

            this.io.emit('playerDeath', {
                playerId,
                killerId,
                killerName: killer?.nickname || 'Unknown',
                victimName: victim?.nickname || 'Unknown'
            });
        };

        this.gameLoop.onPowerUpCollected = (playerId, type) => {
            this.io.emit('powerUpCollected', { playerId, type });
        };

        this.gameLoop.onBlockDestroyed = (blockId, isGolden) => {
            this.io.emit('blockDestroyed', { blockId, isGolden });
        };

        this.gameLoop.onArenaResize = (newSize) => {
            this.io.emit('arenaResize', { size: newSize });
        };

        this.gameLoop.onEventStart = (type) => {
            this.io.emit('eventStarted', { type });
        };

        this.gameLoop.onEventStop = (type) => {
            this.io.emit('eventEnded', { type });
        };
    }

    handleConnection(socket) {
        const ip = socket.handshake.address;
        const count = this.ipConnections.get(ip) || 0;

        if (count >= this.maxConnectionsPerIp) {
            console.warn(`🚫 IP Limit reached for ${ip}`);
            socket.emit('error', 'Слишком много подключений с одного адреса. Не плоди ботов! 🤖');
            socket.disconnect();
            return;
        }

        this.ipConnections.set(ip, count + 1);
        console.log(`🔌 Client connected: ${socket.id} (IP: ${ip}, Count: ${count + 1})`);

        // Send initial game state
        socket.emit('init', {
            playerId: socket.id,
            state: this.gameState.getFullState()
        });

        // Handle player join
        socket.on('join', (data) => {
            this.handleJoin(socket, data);
        });

        // Handle player input
        socket.on('input', (data) => {
            this.handleInput(socket, data);
        });

        // Handle shooting
        socket.on('shoot', () => {
            this.handleShoot(socket);
        });

        // Handle respawn request
        socket.on('respawn', () => {
            this.handleRespawn(socket);
        });

        // Handle ping for latency measurement
        socket.on('ping', (timestamp) => {
            socket.emit('pong', timestamp);
        });

        // Handle disconnect
        socket.on('disconnect', () => {
            this.handleDisconnect(socket);
        });
    }

    handleJoin(socket, data) {
        // Anti-bot handshake check
        if (!data || data.token !== this.handshakeSecret) {
            console.warn(`🤖 Bot detected in join! Missing/invalid token from ${socket.id}`);
            socket.emit('error', 'Ошибка авторизации. Попробуй обновить страницу. 🛡️');
            socket.disconnect();
            return;
        }

        // Check if server is full (limit 50 players)
        if (this.gameState.getPlayerCount() >= 50) {
            socket.emit('serverFull', { message: 'На арене сейчас слишком жарко! Сервер переполнен. Попробуй зайти через 5 минут или загляни в мой Telegram, чтобы узнать, когда мы расширим мощности' });
            return;
        }

        const nickname = (data.nickname || 'Player').substring(0, 16);
        const player = this.gameState.addPlayer(socket.id, nickname);

        console.log(`🎮 ${nickname} joined the game`);

        // Notify all players
        this.io.emit('playerJoined', {
            id: player.id,
            nickname: player.nickname
        });

        // Send full initial state and current leaderboard
        socket.emit('gameState', this.gameState.getFullState());
        socket.emit('leaderboard', this.gameState.getLeaderboardData());
    }

    handleInput(socket, input) {
        // Rate limiting check
        const now = Date.now();
        const lastPacketTime = this.packetRates.get(socket.id) || 0;
        if (now - lastPacketTime < this.packetLimit) return;
        this.packetRates.set(socket.id, now);

        const player = this.gameState.getPlayer(socket.id);
        if (player && player.isAlive) {
            // Validate sequence number to prevent replay/out-of-order
            if (input.seq <= (player.lastInputSeq || 0)) return;

            player.updateInput(input);

            // ANTI-BOT: Heuristic kick
            if (player.roboticScore > 50) {
                console.warn(`🤖 Kicking suspected bot ${player.id} (${player.nickname}) - roboticScore: ${player.roboticScore}`);
                socket.emit('error', 'Обнаружена подозрительная активность (бот). 🤖⛔');
                socket.disconnect();
            }

            // Sanitize turret angle
        }
    }

    handleShoot(socket) {
        // Rate limiting check for shooting specifically (prevent packet flood abuse)
        const now = Date.now();
        const lastPacketTime = this.packetRates.get(socket.id + '_shoot') || 0;
        if (now - lastPacketTime < 200) { // Max 5 shoot attempts per second (server logic handles cooldown too)
            return;
        }
        this.packetRates.set(socket.id + '_shoot', now);

        const bullets = this.gameLoop.playerShoot(socket.id);

        if (bullets.length > 0) {
            // Broadcast new bullets
            this.io.emit('bulletsCreated', {
                playerId: socket.id,
                bullets: bullets.map(b => b.serialize())
            });
        }
    }

    handleRespawn(socket) {
        const player = this.gameLoop.respawnPlayer(socket.id);

        if (player) {
            socket.emit('respawned', {
                player: player.serialize()
            });

            this.io.emit('playerRespawned', {
                playerId: socket.id
            });
        }
    }

    handleDisconnect(socket) {
        const ip = socket.handshake.address;
        const count = this.ipConnections.get(ip) || 1;
        if (count <= 1) {
            this.ipConnections.delete(ip);
        } else {
            this.ipConnections.set(ip, count - 1);
        }

        const player = this.gameState.getPlayer(socket.id);
        const nickname = player?.nickname || 'Unknown';

        this.gameState.removePlayer(socket.id);
        this.packetRates.delete(socket.id);
        this.packetRates.delete(socket.id + '_shoot');

        console.log(`👋 ${nickname} left the game (IP: ${ip})`);

        this.io.emit('playerLeft', {
            id: socket.id,
            nickname
        });
    }

    broadcastGameState() {
        // Optimized: send different states to different players based on AOI
        for (const [playerId, player] of this.gameState.players) {
            const socket = this.io.sockets.sockets.get(playerId);
            if (socket) {
                socket.emit('gameState', this.gameState.getStateForPlayer(playerId));
            }
        }
    }

    broadcastLeaderboard() {
        this.io.emit('leaderboard', this.gameState.getLeaderboardData());
    }
}
