import React, { useState, useCallback } from 'react';

export function SpawnScreen({ onJoin, connected, isDeath = false, killedBy = null, nickname = '', respawnTimer = 0 }) {
    const [inputNickname, setInputNickname] = useState(nickname || '');

    const handleSubmit = useCallback((e) => {
        e.preventDefault();
        if (respawnTimer > 0) return; // Prevent join if timer active
        const name = inputNickname.trim() || 'Player';
        onJoin(name);
    }, [inputNickname, onJoin, respawnTimer]);

    return (
        <div className={`spawn-screen ${isDeath ? 'is-death' : ''}`}>
            <div className="menu-inner">
                <h1>TANCHIKI.io</h1>

                {isDeath && killedBy && (
                    <div className="death-info">
                        Killed by <span className="killer-name">{killedBy}</span>
                    </div>
                )}

                <p className="subtitle">
                    {isDeath ? (respawnTimer > 0 ? `Respawn in ${respawnTimer}s` : 'Try again?') : 'Multiplayer Tank Battle'}
                </p>

                <form onSubmit={handleSubmit} className="spawn-form">
                    {!isDeath && (
                        <div className="input-group">
                            <input
                                type="text"
                                placeholder="Enter your nickname"
                                value={inputNickname}
                                onChange={(e) => setInputNickname(e.target.value)}
                                maxLength={16}
                                autoFocus
                            />
                        </div>
                    )}

                    <button
                        type="submit"
                        className={`play-button ${!connected ? 'loading' : ''}`}
                        disabled={!connected || respawnTimer > 0}
                    >
                        {!connected ? (
                            <span className="btn-text">Connecting...</span>
                        ) : (
                            <span className="btn-text">
                                {isDeath ? (respawnTimer > 0 ? `Wait ${respawnTimer}s` : 'RESPAWN') : 'PLAY'}
                            </span>
                        )}
                    </button>
                </form>

                <div className="controls-hint">
                    <p><strong>WASD</strong> to move • <strong>Mouse</strong> to aim • <strong>Click</strong> to shoot</p>
                    <p className="mobile-only"><strong>Joysticks</strong> to move, aim & shoot</p>
                </div>
            </div>
        </div>
    );
}
