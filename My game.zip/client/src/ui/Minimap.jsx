import React from 'react';

export const Minimap = ({ players, arenaSize, localPlayerId }) => {
    if (!arenaSize) return null;

    const mapSize = 150; // pixels
    const scale = mapSize / arenaSize;

    return (
        <div className="minimap">
            <div className="minimap-container" style={{ width: mapSize, height: mapSize }}>
                {players.map(player => {
                    const isLocal = player.id === localPlayerId;
                    const dotX = (player.x / arenaSize + 0.5) * mapSize;
                    const dotZ = (player.z / arenaSize + 0.5) * mapSize;

                    if (!player.a) return null; // Only show alive players

                    return (
                        <div
                            key={player.id}
                            className={`minimap-dot ${isLocal ? 'local' : ''}`}
                            style={{
                                left: dotX,
                                top: dotZ,
                                backgroundColor: isLocal ? '#4ade80' : '#ef4444'
                            }}
                        />
                    );
                })}
            </div>
        </div>
    );
};
