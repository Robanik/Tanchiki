// ============================================
// TouchControls - Mobile touch handler
// ============================================

export class TouchControls {
    constructor() {
        // Touch state is handled by MobileControls component
        // This class can be extended for additional touch features
    }
    
    dispose() {
        // Cleanup if needed
    }
}
