// ============================================
// Game - Main client game controller
// ============================================

import { Renderer } from './Renderer.js';
import { Tank } from './Tank.js';
import { BulletManager } from './Bullet.js';
import { PowerUpManager } from './PowerUp.js';
import { BlockManager } from './DestructibleBlock.js';
import { Arena } from './Arena.js';
import { ParticleSystem } from './ParticleSystem.js';
import { InputManager } from '../input/InputManager.js';
import { Interpolation } from '../network/Interpolation.js';
import { AudioManager } from '../audio/AudioManager.js';

export class Game {
    constructor(container) {
        this.container = container;

        // Core systems
        this.renderer = new Renderer(container);
        this.inputManager = new InputManager(container, this.renderer.camera, this.renderer);
        this.interpolation = new Interpolation();
        this.audioManager = new AudioManager();

        // Game objects
        this.tanks = new Map();           // id -> Tank
        this.localPlayerId = null;

        // Managers (using InstancedMesh)
        this.bulletManager = new BulletManager(this.renderer.scene);
        this.powerUpManager = new PowerUpManager(this.renderer.scene);
        this.blockManager = new BlockManager(this.renderer.scene);
        this.particleSystem = new ParticleSystem(this.renderer.scene);

        // Arena
        this.arena = new Arena(this.renderer.scene);

        // Game loop
        this.isRunning = false;
        this.lastTime = 0;

        // Network callback
        this.onInput = null;
        this.onShoot = null;

        // Prediction & Reconciliation
        this.pendingInputs = [];      // [{input, deltaTime}]
        this.lastServerSeq = 0;
    }

    setLocalPlayerId(id) {
        this.localPlayerId = id;
    }

    setNetworkCallbacks(onInput, onShoot) {
        this.onInput = onInput;
        this.onShoot = onShoot;

        // Connect shooting to input manager
        this.inputManager.onShoot = () => {
            if (this.onShoot) {
                this.onShoot();
                this.audioManager.play('shoot');
            }
        };
    }

    start() {
        this.isRunning = true;
        this.lastTime = performance.now();
        this.loop();
    }

    stop() {
        this.isRunning = false;
    }

    loop() {
        if (!this.isRunning) return;

        requestAnimationFrame(() => this.loop());

        const now = performance.now();
        const deltaTime = (now - this.lastTime) / 1000;
        this.lastTime = now;

        this.update(deltaTime);
        this.render();
    }

    update(deltaTime) {
        // Update input
        const input = this.inputManager.getInput();

        // Send input to server
        if (this.onInput && this.localPlayerId) {
            this.onInput(input);
        }

        // Update interpolation
        this.interpolation.update(deltaTime);

        // Update tanks with interpolated positions
        for (const [id, tank] of this.tanks) {
            const state = this.interpolation.getState(id);
            if (state) {
                tank.updateFromState(state, deltaTime);
            }
        }

        // Update local tank with immediate response (client prediction)
        const localTank = this.tanks.get(this.localPlayerId);
        if (localTank) {
            localTank.updateTurret(input.angle);

            // Client-Side Prediction (CSP)
            this.predictMovement(localTank, input, deltaTime);

            // Update camera to follow local player
            this.renderer.updateCamera(localTank.position.x, localTank.position.z);
        }

        // Update managers
        this.bulletManager.update(deltaTime);
        this.powerUpManager.update(deltaTime);
        this.particleSystem.update(deltaTime);
    }

    predictMovement(tank, input, deltaTime) {
        if (!tank.isAlive) return;

        this.applyInputToTank(tank, input, deltaTime);

        // Store input for reconciliation
        this.pendingInputs.push({ input: { ...input }, deltaTime });
    }

    reconcileLocalPlayer(serverState) {
        const localTank = this.tanks.get(this.localPlayerId);
        if (!localTank) return;

        // Update stats
        localTank.setAlive(serverState.a);
        localTank.setInvulnerable(serverState.inv);
        localTank.hasSpeedBoost = serverState.sp;

        // Remove processed inputs from history
        this.pendingInputs = this.pendingInputs.filter(item => item.input.seq > serverState.seq);

        // Save current predicted position for comparison
        const currentX = localTank.position.x;
        const currentZ = localTank.position.z;

        // Temporarily snap to server position as a starting point for re-prediction
        localTank.setPosition(serverState.x, serverState.z);

        // Re-apply all pending inputs from the server-validated position
        for (const item of this.pendingInputs) {
            this.applyInputToTank(localTank, item.input, item.deltaTime);
        }

        // Calculate re-predicted position
        const targetX = localTank.position.x;
        const targetZ = localTank.position.z;

        // SOFT RECONCILIATION: Instead of snapping, we lerp towards the target position
        // This eliminates the "jitter" or "snap" felt during reconciliation
        const dx = targetX - currentX;
        const dz = targetZ - currentZ;
        const distSq = dx * dx + dz * dz;

        if (distSq > 0.001) {
            // Smoothly interpolate: move a percentage of the way to the corrected position
            // If the error is massive (e.g. teleport/respawn), snap immediately
            const lerpFactor = distSq > 1000 ? 1.0 : 0.25;

            localTank.position.x = currentX + dx * lerpFactor;
            localTank.position.z = currentZ + dz * lerpFactor;
        } else {
            // Error is negligible, stick with current client position
            localTank.position.x = currentX;
            localTank.position.z = currentZ;
        }
    }

    applyInputToTank(tank, input, deltaTime) {
        // Physics constants (should match server)
        const acceleration = 800;
        const friction = 5;
        let maxSpeed = 150; // Matches server playerSpeed

        if (tank.hasSpeedBoost) maxSpeed *= 1.5;

        // Calculate input direction
        let inputX = 0, inputZ = 0;
        if (input.up) inputZ -= 1;
        if (input.down) inputZ += 1;
        if (input.left) inputX -= 1;
        if (input.right) inputX += 1;

        // Normalize input
        if (inputX !== 0 && inputZ !== 0) {
            const len = Math.sqrt(inputX * inputX + inputZ * inputZ);
            inputX /= len;
            inputZ /= len;
        }

        // Apply acceleration to velocity
        tank.vx = (tank.vx || 0) + inputX * acceleration * deltaTime;
        tank.vz = (tank.vz || 0) + inputZ * acceleration * deltaTime;

        // Apply friction
        tank.vx -= tank.vx * friction * deltaTime;
        tank.vz -= tank.vz * friction * deltaTime;

        // Limit to max speed
        const currentSpeed = Math.sqrt(tank.vx * tank.vx + tank.vz * tank.vz);
        if (currentSpeed > maxSpeed) {
            const ratio = maxSpeed / currentSpeed;
            tank.vx *= ratio;
            tank.vz *= ratio;
        }

        // Apply movement (with small speed cutoff)
        if (Math.abs(tank.vx) < 1) tank.vx = 0;
        if (Math.abs(tank.vz) < 1) tank.vz = 0;

        const nextX = tank.position.x + (tank.vx || 0) * deltaTime;
        const nextZ = tank.position.z + (tank.vz || 0) * deltaTime;

        // Client-side collision resolution
        let finalX = nextX;
        let finalZ = nextZ;
        const playerHalfSize = 25;

        // 1. Resolve Blocks (Multi-pass for robustness)
        for (let pass = 0; pass < 2; pass++) {
            for (const block of this.blockManager.blocks.values()) {
                const halfW = block.width / 2;
                const halfD = block.depth / 2;

                const dx = finalX - block.x;
                const dz = finalZ - block.z;
                const overlapX = playerHalfSize + halfW - Math.abs(dx);
                const overlapZ = playerHalfSize + halfD - Math.abs(dz);

                if (overlapX > 0 && overlapZ > 0) {
                    if (overlapX < overlapZ) {
                        finalX += dx > 0 ? overlapX : -overlapX;
                        tank.vx = 0;
                    } else {
                        finalZ += dz > 0 ? overlapZ : -overlapZ;
                        tank.vz = 0;
                    }
                }
            }
        }

        // 2. Resolve other players (Predictive blocking)
        for (const [id, otherTank] of this.tanks) {
            if (id === this.localPlayerId || !otherTank.isAlive) continue;

            const dx = finalX - otherTank.position.x;
            const dz = finalZ - otherTank.position.z;
            const overlapX = (playerHalfSize + 25) - Math.abs(dx);
            const overlapZ = (playerHalfSize + 25) - Math.abs(dz);

            if (overlapX > 0 && overlapZ > 0) {
                if (overlapX < overlapZ) {
                    finalX += dx > 0 ? overlapX : -overlapX;
                    tank.vx = 0;
                } else {
                    finalZ += dz > 0 ? overlapZ : -overlapZ;
                    tank.vz = 0;
                }
            }
        }

        tank.position.x = finalX;
        tank.position.z = finalZ;

        // Update body rotation based on actual velocity
        if (Math.abs(tank.vx) > 1 || Math.abs(tank.vz) > 1) {
            tank.setBodyAngle(Math.atan2(tank.vx, -tank.vz));
        }
    }

    render() {
        this.renderer.render();
    }

    // Called when receiving state from server
    updateFromServer(state) {
        if (!state) return;

        // Update arena size
        if (state.arenaSize) {
            this.arena.setSize(state.arenaSize);
        }

        // Update players/tanks
        if (state.players) {
            this.updateTanks(state.players);
        }

        // Update bullets
        if (state.bullets) {
            this.bulletManager.updateFromServer(state.bullets);
        }

        // Update power-ups
        if (state.powerUps) {
            this.powerUpManager.updateFromServer(state.powerUps);
        }

        // Update blocks
        if (state.blocks) {
            this.blockManager.updateFromServer(state.blocks);
        }
    }

    updateTanks(playersData) {
        const activeIds = new Set();

        // Find leader (highest score)
        let leaderId = null;
        let maxScore = -1;

        for (const data of playersData) {
            if (data.s > maxScore) {
                maxScore = data.s;
                leaderId = data.id;
            }
        }

        for (const data of playersData) {
            activeIds.add(data.id);

            // Client-Side Prediction: Local player uses reconciliation, others use interpolation
            if (data.id === this.localPlayerId) {
                this.reconcileLocalPlayer(data);
            } else {
                this.interpolation.addState(data.id, {
                    x: data.x,
                    z: data.z,
                    bodyAngle: data.ba,
                    turretAngle: data.ta,
                    hp: data.hp,
                    isAlive: data.a,
                    invulnerable: data.inv,
                    hasTripleShot: data.ts,
                    hasSpeedBoost: data.sp
                });
            }

            // Create tank if doesn't exist
            if (!this.tanks.has(data.id)) {
                const isLocal = data.id === this.localPlayerId;
                const tank = new Tank(data.id, data.n, isLocal, data.c);
                tank.setPosition(data.x, data.z);
                this.renderer.scene.add(tank.group);
                this.tanks.set(data.id, tank);
            }

            // Update tank visibility
            const tank = this.tanks.get(data.id);
            if (tank) {
                tank.setAlive(data.a);
                tank.setInvulnerable(data.inv);
                tank.setLeader(data.id === leaderId && maxScore > 0);
            }
        }

        // Remove tanks that are no longer in state
        for (const [id, tank] of this.tanks) {
            if (!activeIds.has(id)) {
                this.renderer.scene.remove(tank.group);
                tank.dispose();
                this.tanks.delete(id);
            }
        }
    }

    // Event handlers for network events
    onPlayerHit(targetId, shooterId, damage) {
        const tank = this.tanks.get(targetId);
        if (tank) {
            this.particleSystem.spawnHit(tank.position.x, 10, tank.position.z);
            this.audioManager.play('hit');
        }
    }

    onPlayerDeath(playerId, killerId) {
        const tank = this.tanks.get(playerId);
        if (tank) {
            this.particleSystem.spawnExplosion(tank.position.x, 10, tank.position.z);
            this.audioManager.play('explosion');
        }
    }

    onPowerUpCollected(playerId, type) {
        this.audioManager.play('powerup');
    }

    onBlockDestroyed(blockId) {
        const block = this.blockManager.blocks.get(blockId);
        if (block) {
            this.particleSystem.spawnBlockDestroy(block.x, block.y, block.z);
        }
        this.audioManager.play('blockDestroy');
    }

    onBulletsCreated(playerId, bullets) {
        const tank = this.tanks.get(playerId);
        if (tank && bullets && bullets.length > 0) {
            // Trigger recoil
            tank.shootRecoil();

            // Trigger muzzle flash at gun tip
            const gunLength = 40;
            const muzzleX = tank.position.x + Math.sin(tank.targetTurretAngle) * gunLength;
            const muzzleZ = tank.position.z - Math.cos(tank.targetTurretAngle) * gunLength;
            this.particleSystem.spawnMuzzleFlash(muzzleX, 27, muzzleZ);
        }
    }

    dispose() {
        this.stop();

        for (const tank of this.tanks.values()) {
            tank.dispose();
        }
        this.tanks.clear();

        this.bulletManager.dispose();
        this.powerUpManager.dispose();
        this.blockManager.dispose();
        this.particleSystem.dispose();
        this.arena.dispose();
        this.renderer.dispose();
        this.inputManager.dispose();
    }
}
